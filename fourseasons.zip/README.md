# Four Seasons (Forge 1.20.1)

- 4 seasons, 20 game days each (config: `daysPerSeason`)
- Player temperature (cold / heat), leather armor and fires help
- Weather events: thunderstorm (spring), heatwave (summer), fog (autumn), blizzard (winter)
- Winter freezes water and drops snow, other seasons melt it
- Seasonal foliage and grass colors, season title on change, HUD
- Seasonal mobs: strays (winter), husks (summer), witches (autumn nights)
- Crops: faster in spring, almost stopped in winter
- Items: Calendar, Thermometer (crafting recipes included)
- Commands: `/season`, `/season set <spring|summer|autumn|winter>`, `/season event <none|thunderstorm|heatwave|fog|blizzard>`
- In winter all precipitation is snow (Biome mixin), including after `/weather rain`; hot biomes (desert, savanna, badlands) stay dry/warm
