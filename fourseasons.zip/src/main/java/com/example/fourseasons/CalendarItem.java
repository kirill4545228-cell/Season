package com.example.fourseasons;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class CalendarItem extends Item {
    public CalendarItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel sl) {
            SeasonManager.Info info = SeasonManager.info(sl);
            SeasonEvent ev = SeasonManager.event(sl);
            int left = info.daysPerSeason() - info.dayInSeason() + 1;

            player.sendSystemMessage(Component.translatable("msg.fourseasons.calendar.today",
                    info.season().displayName().copy().withStyle(net.minecraft.network.chat.Style.EMPTY.withColor(info.season().color)),
                    info.dayInSeason(), info.daysPerSeason()));
            player.sendSystemMessage(Component.translatable("msg.fourseasons.calendar.next",
                    info.season().next().displayName(), left).withStyle(ChatFormatting.GRAY));
            long seed = sl.getSeed();
            boolean precip = WeatherSchedule.isPrecipDay(seed, info);
            player.sendSystemMessage(Component.translatable("msg.fourseasons.calendar.precip",
                    Component.translatable(precip ? "msg.fourseasons.yes" : "msg.fourseasons.no"),
                    WeatherSchedule.precipDaysInSeason(seed, info), info.daysPerSeason()).withStyle(ChatFormatting.AQUA));
            if (ev != SeasonEvent.NONE) {
                player.sendSystemMessage(Component.translatable("msg.fourseasons.calendar.event", ev.displayName())
                        .withStyle(ChatFormatting.GOLD));
            }
            player.getCooldowns().addCooldown(this, 20);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.fourseasons.calendar.desc").withStyle(ChatFormatting.GRAY));
    }
}
