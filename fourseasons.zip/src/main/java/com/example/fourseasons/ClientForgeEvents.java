package com.example.fourseasons;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FourSeasons.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private static int lastSeason = -1;

    private ClientForgeEvents() {}

    /** Re-mesh chunks when the season changes so foliage colors update. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        int s = ClientSeasonData.season;
        if (s != lastSeason) {
            lastSeason = s;
            Minecraft mc = Minecraft.getInstance();
            if (s >= 0 && mc.level != null && mc.levelRenderer != null) {
                mc.levelRenderer.allChanged();
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientSeasonData.reset();
    }

    /** Autumn fog and blizzard: reduced visibility. */
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        if (!ClientSeasonData.overworld) return;
        if (ClientSeasonData.event == SeasonEvent.FOG.ordinal()) {
            e.setNearPlaneDistance(0f);
            e.setFarPlaneDistance(28f);
            e.setCanceled(true);
        } else if (ClientSeasonData.event == SeasonEvent.BLIZZARD.ordinal()) {
            e.setNearPlaneDistance(0f);
            e.setFarPlaneDistance(40f);
            e.setCanceled(true);
        }
    }
}
