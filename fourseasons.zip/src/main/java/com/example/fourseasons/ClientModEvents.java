package com.example.fourseasons;

import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.world.level.FoliageColor;
import net.minecraft.world.level.GrassColor;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FourSeasons.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onBlockColors(RegisterColorHandlersEvent.Block e) {
        e.register((state, level, pos, tint) -> SeasonColors.leaves(
                        level != null && pos != null ? BiomeColors.getAverageFoliageColor(level, pos) : FoliageColor.getDefaultColor(), pos),
                Blocks.OAK_LEAVES, Blocks.DARK_OAK_LEAVES, Blocks.JUNGLE_LEAVES, Blocks.ACACIA_LEAVES, Blocks.MANGROVE_LEAVES);

        e.register((state, level, pos, tint) -> SeasonColors.birch(FoliageColor.getBirchColor(), pos),
                Blocks.BIRCH_LEAVES);

        e.register((state, level, pos, tint) -> SeasonColors.spruce(FoliageColor.getEvergreenColor()),
                Blocks.SPRUCE_LEAVES);

        e.register((state, level, pos, tint) -> SeasonColors.grass(
                        level != null && pos != null ? BiomeColors.getAverageGrassColor(level, pos) : GrassColor.getDefaultColor()),
                Blocks.GRASS_BLOCK, Blocks.GRASS, Blocks.FERN, Blocks.TALL_GRASS, Blocks.LARGE_FERN);
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("season_hud", SeasonHud::render);
    }
}
