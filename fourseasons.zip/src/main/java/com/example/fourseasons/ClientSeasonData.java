package com.example.fourseasons;

/** Season state mirrored on the client. Plain static fields, safe to load on any side. */
public final class ClientSeasonData {
    public static volatile boolean overworld = false;
    public static volatile int season = -1;
    public static volatile int day = 1;
    public static volatile int daysPerSeason = 20;
    public static volatile int event = 0;
    public static volatile float ambient = 20f;
    public static volatile float body = 20f;

    private ClientSeasonData() {}

    public static void update(SyncPacket p) {
        overworld = p.overworld();
        season = p.season();
        day = p.day();
        daysPerSeason = p.daysPerSeason();
        event = p.event();
        ambient = p.ambient();
        body = p.body();
        SeasonHooks.clientWinter = p.overworld() && p.season() == Season.WINTER.ordinal();
    }

    public static void reset() {
        overworld = false;
        season = -1;
        event = 0;
        SeasonHooks.clientWinter = false;
    }
}
