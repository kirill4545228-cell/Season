package com.example.fourseasons;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/** Winter: water freezes and snow settles. Other seasons: ice and snow melt (except in permanently cold biomes). */
public final class FreezeThaw {
    private FreezeThaw() {}

    public static void tick(ServerLevel level) {
        Season season = SeasonManager.season(level);
        RandomSource r = level.random;

        for (ServerPlayer p : level.players()) {
            BlockPos c = p.blockPosition();
            for (int i = 0; i < 24; i++) {
                int x = c.getX() + r.nextInt(81) - 40;
                int z = c.getZ() + r.nextInt(81) - 40;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;

                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos top = new BlockPos(x, y, z);
                float bt = level.getBiome(top).value().getBaseTemperature();

                if (season == Season.WINTER) {
                    if (bt < 1.0f) freeze(level, top);
                } else if (bt > 0.15f) {
                    thaw(level, top);
                }
            }
        }
    }

    private static void freeze(ServerLevel level, BlockPos top) {
        if (!level.getBlockState(top).isAir()) return;
        if (level.getBrightness(LightLayer.BLOCK, top) >= 10) return;

        BlockPos below = top.below();
        BlockState bs = level.getBlockState(below);
        if (bs.is(Blocks.WATER) && bs.getFluidState().isSource()) {
            level.setBlockAndUpdate(below, Blocks.ICE.defaultBlockState());
        } else if (Blocks.SNOW.defaultBlockState().canSurvive(level, top)) {
            level.setBlockAndUpdate(top, Blocks.SNOW.defaultBlockState());
        }
    }

    private static void thaw(ServerLevel level, BlockPos top) {
        for (BlockPos pos : new BlockPos[] {top, top.below()}) {
            BlockState st = level.getBlockState(pos);
            if (st.is(Blocks.SNOW)) {
                level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                return;
            }
            if (st.is(Blocks.ICE)) {
                level.setBlockAndUpdate(pos, Blocks.WATER.defaultBlockState());
                return;
            }
        }
    }
}
