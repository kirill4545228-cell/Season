package com.example.fourseasons;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Winter: water freezes; snow settles ONLY while it is actually snowing (precipitation).
 * Other seasons: ice and snow melt (except in permanently cold biomes).
 */
public final class FreezeThaw {
    private FreezeThaw() {}

    public static void tick(ServerLevel level) {
        Season season = SeasonManager.season(level);
        boolean precipitating = level.isRaining();
        RandomSource r = level.random;

        for (ServerPlayer p : level.players()) {
            BlockPos c = p.blockPosition();
            for (int i = 0; i < 24; i++) {
                int x = c.getX() + r.nextInt(81) - 40;
                int z = c.getZ() + r.nextInt(81) - 40;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;

                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos top = new BlockPos(x, y, z);
                float bt = level.getBiome(top).value().getBaseTemperature();

                if (season == Season.WINTER) {
                    if (bt >= 1.0f) continue;
                    freezeWater(level, top);
                    if (precipitating) snowfall(level, top, r);
                } else if (bt > 0.15f) {
                    thaw(level, top);
                }
            }
        }
    }

    private static void freezeWater(ServerLevel level, BlockPos top) {
        if (!level.getBlockState(top).isAir()) return;
        if (level.getBrightness(LightLayer.BLOCK, top) >= 10) return;
        BlockPos below = top.below();
        BlockState bs = level.getBlockState(below);
        if (bs.is(Blocks.WATER) && bs.getFluidState().isSource()) {
            level.setBlockAndUpdate(below, Blocks.ICE.defaultBlockState());
        }
    }

    /** Snow only builds up while snowing: a thin layer first, then slowly up to 3 layers. */
    private static void snowfall(ServerLevel level, BlockPos top, RandomSource r) {
        if (!level.canSeeSky(top)) return;
        if (level.getBrightness(LightLayer.BLOCK, top) >= 10) return;

        BlockPos snowPos = null;
        if (level.getBlockState(top).is(Blocks.SNOW)) {
            snowPos = top;
        } else if (level.getBlockState(top.below()).is(Blocks.SNOW)) {
            snowPos = top.below();
        }

        if (snowPos != null) {
            BlockState st = level.getBlockState(snowPos);
            int layers = st.getValue(SnowLayerBlock.LAYERS);
            if (layers < 3 && r.nextFloat() < 0.25f) {
                level.setBlockAndUpdate(snowPos, st.setValue(SnowLayerBlock.LAYERS, layers + 1));
            }
            return;
        }

        if (level.getBlockState(top).isAir() && Blocks.SNOW.defaultBlockState().canSurvive(level, top)) {
            level.setBlockAndUpdate(top, Blocks.SNOW.defaultBlockState());
        }
    }

    private static void thaw(ServerLevel level, BlockPos top) {
        for (BlockPos pos : new BlockPos[] {top, top.below()}) {
            BlockState st = level.getBlockState(pos);
            if (st.is(Blocks.SNOW)) {
                level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                return;
            }
            if (st.is(Blocks.ICE)) {
                level.setBlockAndUpdate(pos, Blocks.WATER.defaultBlockState());
                return;
            }
        }
    }
}
