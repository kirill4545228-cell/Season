package com.example.fourseasons;

import net.minecraft.network.chat.Component;

public enum Season {
    SPRING("spring", 12f, 0x7CFC00),
    SUMMER("summer", 28f, 0xFFD54F),
    AUTUMN("autumn", 7f, 0xFF8C00),
    WINTER("winter", -6f, 0x9AD7FF);

    public final String id;
    public final float baseTemp;
    public final int color;

    Season(String id, float baseTemp, int color) {
        this.id = id;
        this.baseTemp = baseTemp;
        this.color = color;
    }

    public Component displayName() {
        return Component.translatable("season.fourseasons." + id);
    }

    public Season next() {
        return values()[(ordinal() + 1) % 4];
    }

    public static Season byIndex(int i) {
        return values()[Math.floorMod(i, 4)];
    }
}
