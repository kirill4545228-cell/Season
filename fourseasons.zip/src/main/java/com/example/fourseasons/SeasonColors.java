package com.example.fourseasons;

import net.minecraft.core.BlockPos;

/** Seasonal foliage/grass tint math (pure int math, used by client color handlers). */
public final class SeasonColors {
    private static final int[] AUTUMN_LEAVES = {0xE07A1F, 0xC0392B, 0xD4A017, 0xB5651D};

    private SeasonColors() {}

    public static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static int patch(BlockPos pos) {
        if (pos == null) return 0;
        return Math.floorMod((pos.getX() >> 2) * 31 + (pos.getY() >> 2) * 7 + (pos.getZ() >> 2) * 17, AUTUMN_LEAVES.length);
    }

    public static int leaves(int base, BlockPos pos) {
        int s = ClientSeasonData.season;
        if (s < 0) return base;
        return switch (Season.byIndex(s)) {
            case SPRING -> mix(base, 0x8CE86A, 0.25f);
            case SUMMER -> base;
            case AUTUMN -> mix(base, AUTUMN_LEAVES[patch(pos)], 0.85f);
            case WINTER -> mix(base, 0x8E9A8E, 0.55f);
        };
    }

    public static int birch(int base, BlockPos pos) {
        int s = ClientSeasonData.season;
        if (s < 0) return base;
        return switch (Season.byIndex(s)) {
            case SPRING -> mix(base, 0x9BE87A, 0.2f);
            case SUMMER -> base;
            case AUTUMN -> mix(base, 0xE8C32A, 0.9f);
            case WINTER -> mix(base, 0xB8B8A8, 0.5f);
        };
    }

    public static int spruce(int base) {
        int s = ClientSeasonData.season;
        if (s < 0) return base;
        return Season.byIndex(s) == Season.WINTER ? mix(base, 0xDDE8E8, 0.3f) : base;
    }

    public static int grass(int base) {
        int s = ClientSeasonData.season;
        if (s < 0) return base;
        return switch (Season.byIndex(s)) {
            case SPRING -> mix(base, 0x7CDB3A, 0.2f);
            case SUMMER -> base;
            case AUTUMN -> mix(base, 0xB0A040, 0.5f);
            case WINTER -> mix(base, 0xE6EEF0, 0.6f);
        };
    }
}
