package com.example.fourseasons;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FourSeasons.MODID)
public final class SeasonCommand {
    private SeasonCommand() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("season")
                .executes(c -> info(c.getSource()));

        LiteralArgumentBuilder<CommandSourceStack> set = Commands.literal("set")
                .requires(src -> src.hasPermission(2));
        for (Season season : Season.values()) {
            set.then(Commands.literal(season.id).executes(c -> setSeason(c.getSource(), season)));
        }

        LiteralArgumentBuilder<CommandSourceStack> event = Commands.literal("event")
                .requires(src -> src.hasPermission(2));
        for (SeasonEvent se : SeasonEvent.values()) {
            event.then(Commands.literal(se.id).executes(c -> setEvent(c.getSource(), se)));
        }

        e.getDispatcher().register(root.then(set).then(event));
    }

    private static int info(CommandSourceStack src) {
        ServerLevel level = src.getLevel();
        SeasonManager.Info info = SeasonManager.info(level);
        SeasonEvent ev = SeasonManager.event(level);
        src.sendSuccess(() -> Component.translatable("msg.fourseasons.calendar.today",
                info.season().displayName(), info.dayInSeason(), info.daysPerSeason()), false);
        if (ev != SeasonEvent.NONE) {
            src.sendSuccess(() -> Component.translatable("msg.fourseasons.calendar.event", ev.displayName()), false);
        }
        return 1;
    }

    private static int setSeason(CommandSourceStack src, Season season) {
        SeasonManager.setSeason(src.getLevel(), season);
        src.sendSuccess(() -> Component.translatable("commands.fourseasons.set", season.displayName()), true);
        return 1;
    }

    private static int setEvent(CommandSourceStack src, SeasonEvent ev) {
        ServerLevel level = src.getLevel();
        if (ev == SeasonEvent.NONE) {
            SeasonManager.stopEvent(level, true);
            src.sendSuccess(() -> Component.translatable("commands.fourseasons.event.none"), true);
        } else {
            SeasonManager.startEvent(level, ev, 6000);
            src.sendSuccess(() -> Component.translatable("commands.fourseasons.event.set", ev.displayName()), true);
        }
        return 1;
    }
}
