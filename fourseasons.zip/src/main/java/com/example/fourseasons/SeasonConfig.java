package com.example.fourseasons;

import net.minecraftforge.common.ForgeConfigSpec;

public final class SeasonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue DAYS_PER_SEASON;
    public static final ForgeConfigSpec.BooleanValue TEMPERATURE;
    public static final ForgeConfigSpec.BooleanValue EVENTS;
    public static final ForgeConfigSpec.BooleanValue FREEZE_WORLD;
    public static final ForgeConfigSpec.BooleanValue SEASONAL_MOBS;
    public static final ForgeConfigSpec.BooleanValue CROPS;
    public static final ForgeConfigSpec.BooleanValue HUD;
    public static final ForgeConfigSpec.BooleanValue WEATHER_CONTROL;
    public static final ForgeConfigSpec.IntValue PRECIP_SPRING;
    public static final ForgeConfigSpec.IntValue PRECIP_SUMMER;
    public static final ForgeConfigSpec.IntValue PRECIP_AUTUMN;
    public static final ForgeConfigSpec.IntValue PRECIP_WINTER;
    public static final ForgeConfigSpec.IntValue PRECIP_VARIANCE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("seasons");
        DAYS_PER_SEASON = b.comment("Length of one season in game days")
                .defineInRange("daysPerSeason", 20, 1, 365);
        TEMPERATURE = b.comment("Enable player body temperature (cold and heat)")
                .define("temperature", true);
        EVENTS = b.comment("Enable random seasonal weather events")
                .define("weatherEvents", true);
        FREEZE_WORLD = b.comment("Water freezes and snow falls in winter, melts in other seasons")
                .define("freezeAndThaw", true);
        SEASONAL_MOBS = b.comment("Seasonal mob variants (strays in winter, husks in summer, witches on autumn nights)")
                .define("seasonalMobs", true);
        CROPS = b.comment("Crops grow faster in spring and almost stop in winter")
                .define("seasonalCrops", true);
        HUD = b.comment("Show season / temperature HUD (client)")
                .define("hud", true);
        b.pop();

        b.push("precipitation");
        WEATHER_CONTROL = b.comment("The mod controls rain/snow: precipitation only on scheduled days of each season")
                .define("weatherControl", true);
        PRECIP_SPRING = b.comment("Rainy days per 20-day season (scaled if season length differs)")
                .defineInRange("springDays", 9, 0, 20);
        PRECIP_SUMMER = b.defineInRange("summerDays", 4, 0, 20);
        PRECIP_AUTUMN = b.defineInRange("autumnDays", 12, 0, 20);
        PRECIP_WINTER = b.comment("Snowy days per 20-day season")
                .defineInRange("winterDays", 15, 0, 20);
        PRECIP_VARIANCE = b.comment("Random +/- change of the number of precipitation days each season")
                .defineInRange("variance", 3, 0, 10);
        b.pop();
        SPEC = b.build();
    }

    private SeasonConfig() {}
}
