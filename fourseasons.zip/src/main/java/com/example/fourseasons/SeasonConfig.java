package com.example.fourseasons;

import net.minecraftforge.common.ForgeConfigSpec;

public final class SeasonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue DAYS_PER_SEASON;
    public static final ForgeConfigSpec.BooleanValue TEMPERATURE;
    public static final ForgeConfigSpec.BooleanValue EVENTS;
    public static final ForgeConfigSpec.BooleanValue FREEZE_WORLD;
    public static final ForgeConfigSpec.BooleanValue SEASONAL_MOBS;
    public static final ForgeConfigSpec.BooleanValue CROPS;
    public static final ForgeConfigSpec.BooleanValue HUD;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("seasons");
        DAYS_PER_SEASON = b.comment("Length of one season in game days")
                .defineInRange("daysPerSeason", 20, 1, 365);
        TEMPERATURE = b.comment("Enable player body temperature (cold and heat)")
                .define("temperature", true);
        EVENTS = b.comment("Enable random seasonal weather events")
                .define("weatherEvents", true);
        FREEZE_WORLD = b.comment("Water freezes and snow falls in winter, melts in other seasons")
                .define("freezeAndThaw", true);
        SEASONAL_MOBS = b.comment("Seasonal mob variants (strays in winter, husks in summer, witches on autumn nights)")
                .define("seasonalMobs", true);
        CROPS = b.comment("Crops grow faster in spring and almost stop in winter")
                .define("seasonalCrops", true);
        HUD = b.comment("Show season / temperature HUD (client)")
                .define("hud", true);
        b.pop();
        SPEC = b.build();
    }

    private SeasonConfig() {}
}
