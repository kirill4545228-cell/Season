package com.example.fourseasons;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

public class SeasonData extends SavedData {
    public long offset = 0L;
    public long lastPeriod = Long.MIN_VALUE;
    public int event = 0;
    public long eventEnd = 0L;
    public long lastDay = Long.MIN_VALUE;
    public long rainStart = 0L;
    public long rainEnd = 0L;
    public boolean rainThunder = false;

    public static SeasonData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(SeasonData::load, SeasonData::new, "fourseasons_data");
    }

    public static SeasonData load(CompoundTag tag) {
        SeasonData d = new SeasonData();
        d.offset = tag.getLong("offset");
        d.lastPeriod = tag.contains("lastPeriod") ? tag.getLong("lastPeriod") : Long.MIN_VALUE;
        d.event = tag.getInt("event");
        d.eventEnd = tag.getLong("eventEnd");
        d.lastDay = tag.contains("lastDay") ? tag.getLong("lastDay") : Long.MIN_VALUE;
        d.rainStart = tag.getLong("rainStart");
        d.rainEnd = tag.getLong("rainEnd");
        d.rainThunder = tag.getBoolean("rainThunder");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("offset", offset);
        tag.putLong("lastPeriod", lastPeriod);
        tag.putInt("event", event);
        tag.putLong("eventEnd", eventEnd);
        tag.putLong("lastDay", lastDay);
        tag.putLong("rainStart", rainStart);
        tag.putLong("rainEnd", rainEnd);
        tag.putBoolean("rainThunder", rainThunder);
        return tag;
    }
}
