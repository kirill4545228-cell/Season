package com.example.fourseasons;

import net.minecraft.network.chat.Component;

public enum SeasonEvent {
    NONE("none", 0f),
    THUNDERSTORM("thunderstorm", -3f),
    HEATWAVE("heatwave", 12f),
    FOG("fog", -2f),
    BLIZZARD("blizzard", -14f);

    public final String id;
    public final float tempOffset;

    SeasonEvent(String id, float tempOffset) {
        this.id = id;
        this.tempOffset = tempOffset;
    }

    public Component displayName() {
        return Component.translatable("event.fourseasons." + id);
    }

    public static SeasonEvent byOrdinal(int i) {
        SeasonEvent[] v = values();
        return (i >= 0 && i < v.length) ? v[i] : NONE;
    }

    public static SeasonEvent forSeason(Season s) {
        return switch (s) {
            case SPRING -> THUNDERSTORM;
            case SUMMER -> HEATWAVE;
            case AUTUMN -> FOG;
            case WINTER -> BLIZZARD;
        };
    }
}
