package com.example.fourseasons;

/** Flags read by the Biome mixin. Set by the server tick and by the client sync packet. */
public final class SeasonHooks {
    public static volatile boolean serverWinter = false;
    public static volatile boolean clientWinter = false;

    private SeasonHooks() {}

    public static boolean winter() {
        return serverWinter || clientWinter;
    }

    /** In winter every precipitation falls as snow, except in hot biomes (desert, savanna, badlands). */
    public static boolean forceSnow(float baseTemperature) {
        return winter() && baseTemperature < 1.0f;
    }
}
