package com.example.fourseasons;

import java.util.Locale;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public final class SeasonHud {
    private SeasonHud() {}

    private static String fmt(float v) {
        return String.format(Locale.ROOT, "%.0f", v);
    }

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.renderDebug || !ClientSeasonData.overworld || ClientSeasonData.season < 0) return;
        if (!SeasonConfig.HUD.get()) return;

        Font font = mc.font;
        Season s = Season.byIndex(ClientSeasonData.season);
        int x = 6;
        int y = 6;

        g.drawString(font, Component.translatable("hud.fourseasons.season", s.displayName(),
                ClientSeasonData.day, ClientSeasonData.daysPerSeason), x, y, 0xFF000000 | s.color, true);
        y += 10;

        SeasonEvent ev = SeasonEvent.byOrdinal(ClientSeasonData.event);
        if (ev != SeasonEvent.NONE) {
            g.drawString(font, ev.displayName(), x, y, 0xFFFFAA00, true);
            y += 10;
        }

        if (SeasonConfig.TEMPERATURE.get()) {
            float b = ClientSeasonData.body;
            int col = b < -8f ? 0xFF55AAFF : (b > 36f ? 0xFFFF5555 : 0xFFFFFFFF);
            g.drawString(font, Component.translatable("hud.fourseasons.temp",
                    fmt(ClientSeasonData.ambient), fmt(b)), x, y, col, true);
        }
    }
}
