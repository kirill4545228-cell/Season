package com.example.fourseasons;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

public final class SeasonManager {
    public record Info(long totalDay, Season season, int dayInSeason, int daysPerSeason, long period) {}

    private SeasonManager() {}

    public static ServerLevel overworld(ServerLevel any) {
        return any.getServer().overworld();
    }

    public static Info info(ServerLevel any) {
        ServerLevel ow = overworld(any);
        SeasonData d = SeasonData.get(ow);
        long len = SeasonConfig.DAYS_PER_SEASON.get();
        long day = Math.floorDiv(ow.getDayTime(), 24000L) + d.offset;
        long period = Math.floorDiv(day, len);
        Season s = Season.byIndex((int) Math.floorMod(period, 4L));
        int dayInSeason = (int) Math.floorMod(day, len) + 1;
        return new Info(day, s, dayInSeason, (int) len, period);
    }

    public static Season season(ServerLevel any) {
        return info(any).season();
    }

    public static SeasonEvent event(ServerLevel any) {
        return SeasonEvent.byOrdinal(SeasonData.get(overworld(any)).event);
    }

    public static void setSeason(ServerLevel any, Season target) {
        ServerLevel ow = overworld(any);
        SeasonData d = SeasonData.get(ow);
        long len = SeasonConfig.DAYS_PER_SEASON.get();
        long cur = Math.floorDiv(ow.getDayTime(), 24000L);
        d.offset = target.ordinal() * len - cur;
        d.lastPeriod = Long.MIN_VALUE;
        d.lastDay = Long.MIN_VALUE;
        d.rainStart = 0L;
        d.rainEnd = 0L;
        d.event = 0;
        d.setDirty();
    }

    public static void startEvent(ServerLevel any, SeasonEvent ev, int duration) {
        ServerLevel ow = overworld(any);
        SeasonData d = SeasonData.get(ow);
        d.event = ev.ordinal();
        d.eventEnd = ow.getGameTime() + duration;
        d.setDirty();
        switch (ev) {
            case THUNDERSTORM -> ow.setWeatherParameters(0, duration, true, true);
            case BLIZZARD -> ow.setWeatherParameters(0, duration, true, false);
            case HEATWAVE -> ow.setWeatherParameters(duration, 0, false, false);
            default -> {}
        }
        ow.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("msg.fourseasons.start." + ev.id).withStyle(ChatFormatting.GOLD), false);
    }

    public static void stopEvent(ServerLevel any, boolean announce) {
        ServerLevel ow = overworld(any);
        SeasonData d = SeasonData.get(ow);
        if (d.event == 0) return;
        d.event = 0;
        d.setDirty();
        if (announce) {
            ow.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("msg.fourseasons.end").withStyle(ChatFormatting.GRAY), false);
        }
    }
}
