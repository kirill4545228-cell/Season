package com.example.fourseasons;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = FourSeasons.MODID)
public final class ServerEvents {
    public static final String TEMP_KEY = "fourseasons_body_temp";

    private ServerEvents() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;

        long time = level.getGameTime();
        if (time % 20L == 0L) secondTick(level);
        if (time % 4L == 0L && SeasonConfig.FREEZE_WORLD.get()) FreezeThaw.tick(level);
    }

    private static void secondTick(ServerLevel ow) {
        MinecraftServer server = ow.getServer();
        SeasonData data = SeasonData.get(ow);
        SeasonManager.Info info = SeasonManager.info(ow);
        long now = ow.getGameTime();

        // season change announcement
        if (data.lastPeriod != info.period()) {
            data.lastPeriod = info.period();
            data.setDirty();
            announceSeason(server, info.season());
        }

        // random weather events
        SeasonEvent ev = SeasonEvent.byOrdinal(data.event);
        if (ev != SeasonEvent.NONE && now >= data.eventEnd) {
            SeasonManager.stopEvent(ow, true);
            ev = SeasonEvent.NONE;
        } else if (ev == SeasonEvent.NONE && SeasonConfig.EVENTS.get()
                && !server.getPlayerList().getPlayers().isEmpty() && ow.random.nextInt(2400) == 0) {
            ev = SeasonEvent.forSeason(info.season());
            SeasonManager.startEvent(ow, ev, 6000 + ow.random.nextInt(6000));
        }

        // scheduled precipitation (rain / snow only on planned days)
        if (SeasonConfig.WEATHER_CONTROL.get()) {
            updateWeather(ow, data, info, now, ev);
        }

        // players: temperature + sync
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            boolean inOw = p.level().dimension() == Level.OVERWORLD;
            float body = p.getPersistentData().contains(TEMP_KEY) ? p.getPersistentData().getFloat(TEMP_KEY) : 20f;
            float ambient = 20f;

            if (inOw) {
                ambient = TemperatureManager.ambient(p, info.season(), ev);
                if (SeasonConfig.TEMPERATURE.get()) {
                    body += (ambient - body) * 0.05f;
                    applyBodyEffects(p, body, now);
                } else {
                    body = 20f;
                }
            } else {
                body += (20f - body) * 0.2f;
            }
            p.getPersistentData().putFloat(TEMP_KEY, body);

            Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                    new SyncPacket(inOw, info.season().ordinal(), info.dayInSeason(), info.daysPerSeason(),
                            ev.ordinal(), ambient, body));
        }
    }

    private static void updateWeather(ServerLevel ow, SeasonData data, SeasonManager.Info info, long now, SeasonEvent ev) {
        RandomSource r = ow.random;

        // new game day: plan precipitation for it
        if (data.lastDay != info.totalDay()) {
            data.lastDay = info.totalDay();
            if (WeatherSchedule.isPrecipDay(ow.getSeed(), info)) {
                boolean winter = info.season() == Season.WINTER;
                boolean summer = info.season() == Season.SUMMER;
                int duration = winter ? 6000 + r.nextInt(6000) : (summer ? 2500 + r.nextInt(3500) : 4000 + r.nextInt(5000));
                long base = Math.max(now, data.rainEnd);
                data.rainStart = base + r.nextInt(8000);
                data.rainEnd = data.rainStart + duration;
                float thunder = switch (info.season()) {
                    case SPRING -> 0.25f;
                    case SUMMER -> 0.5f;
                    case AUTUMN -> 0.1f;
                    case WINTER -> 0f;
                };
                data.rainThunder = r.nextFloat() < thunder;
            }
            data.setDirty();
        }

        // events control the weather themselves
        if (ev != SeasonEvent.NONE) return;

        boolean planned = now >= data.rainStart && now < data.rainEnd;
        if (planned) {
            if (!ow.isRaining()) {
                ow.setWeatherParameters(0, (int) (data.rainEnd - now), true, data.rainThunder);
            }
        } else if (ow.isRaining() || ow.isThundering()) {
            ow.setWeatherParameters(6000, 0, false, false);
        }
    }

    private static void applyBodyEffects(ServerPlayer p, float body, long now) {
        if (p.isCreative() || p.isSpectator()) return;
        boolean hurtTick = (now / 20L) % 4L == 0L;

        if (body < -8f) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, body < -20f ? 1 : 0, false, true, true));
        }
        if (body < -20f && hurtTick) {
            p.hurt(p.damageSources().freeze(), body < -30f ? 2f : 1f);
        }
        if (body > 36f) {
            p.causeFoodExhaustion(0.4f);
        }
        if (body > 44f) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, true, true));
        }
        if (body > 52f && hurtTick) {
            p.hurt(p.damageSources().generic(), 1f);
        }
    }

    private static void announceSeason(MinecraftServer server, Season season) {
        Component title = season.displayName().copy().withStyle(Style.EMPTY.withColor(season.color));
        Component sub = Component.translatable("msg.fourseasons.season_begins");
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
            p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
            p.connection.send(new ClientboundSetTitleTextPacket(title));
        }
    }

    /** Cold vignette on the screen while the body is freezing. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        Player p = e.player;
        if (!p.getPersistentData().contains(TEMP_KEY)) return;
        float body = p.getPersistentData().getFloat(TEMP_KEY);
        if (body < -8f && SeasonConfig.TEMPERATURE.get()) {
            int req = p.getTicksRequiredToFreeze();
            int target = (int) (req * Mth.clamp((-8f - body) / 14f, 0f, 0.95f));
            if (p.getTicksFrozen() < target) p.setTicksFrozen(target);
        }
    }

    /** Seasonal mob variants. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (!SeasonConfig.SEASONAL_MOBS.get()) return;
        if (e.loadedFromDisk() || !(e.getLevel() instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        Entity ent = e.getEntity();
        if (!(ent instanceof Mob mob) || mob.tickCount > 0 || mob.isPassenger() || mob.isVehicle()) return;

        EntityType<?> type = mob.getType();
        if (type != EntityType.SKELETON && type != EntityType.ZOMBIE) return;
        if (!level.canSeeSky(mob.blockPosition())) return;

        Season s = SeasonManager.season(level);
        RandomSource r = level.random;
        EntityType<? extends Mob> repl = null;
        if (type == EntityType.SKELETON && s == Season.WINTER && r.nextFloat() < 0.5f) {
            repl = EntityType.STRAY;
        } else if (type == EntityType.ZOMBIE && s == Season.SUMMER && r.nextFloat() < 0.4f) {
            repl = EntityType.HUSK;
        } else if (type == EntityType.ZOMBIE && s == Season.AUTUMN && !level.isDay() && r.nextFloat() < 0.12f) {
            repl = EntityType.WITCH;
        }
        if (repl == null) return;

        Mob n = repl.create(level);
        if (n == null) return;
        n.moveTo(mob.getX(), mob.getY(), mob.getZ(), mob.getYRot(), mob.getXRot());
        n.finalizeSpawn(level, level.getCurrentDifficultyAt(n.blockPosition()), MobSpawnType.NATURAL, null, null);
        level.addFreshEntity(n);
        e.setCanceled(true);
    }

    /** Crops: spring boost, winter slowdown. */
    @SubscribeEvent
    public static void onCropGrow(BlockEvent.CropGrowEvent.Pre e) {
        if (!SeasonConfig.CROPS.get()) return;
        if (!(e.getLevel() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;
        Season s = SeasonManager.season(level);
        if (s == Season.WINTER) {
            if (level.random.nextFloat() < 0.85f) e.setResult(Event.Result.DENY);
        } else if (s == Season.SPRING) {
            if (level.random.nextFloat() < 0.2f) e.setResult(Event.Result.ALLOW);
        }
    }
}
