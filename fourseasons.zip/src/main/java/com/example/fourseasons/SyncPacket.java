package com.example.fourseasons;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public record SyncPacket(boolean overworld, int season, int day, int daysPerSeason, int event, float ambient, float body) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(overworld);
        buf.writeVarInt(season);
        buf.writeVarInt(day);
        buf.writeVarInt(daysPerSeason);
        buf.writeVarInt(event);
        buf.writeFloat(ambient);
        buf.writeFloat(body);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        return new SyncPacket(buf.readBoolean(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                buf.readVarInt(), buf.readFloat(), buf.readFloat());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientSeasonData.update(this));
        ctx.get().setPacketHandled(true);
    }
}
