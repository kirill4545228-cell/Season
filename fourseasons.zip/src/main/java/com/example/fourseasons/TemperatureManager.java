package com.example.fourseasons;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class TemperatureManager {
    private TemperatureManager() {}

    /** Ambient temperature around the player in degrees. */
    public static float ambient(ServerPlayer p, Season season, SeasonEvent ev) {
        ServerLevel level = (ServerLevel) p.level();
        BlockPos pos = p.blockPosition();

        float t = season.baseTemp;
        t += (level.getBiome(pos).value().getBaseTemperature() - 0.8f) * 8f;

        long dt = level.getDayTime() % 24000L;
        if (dt >= 13000L && dt <= 23000L) t -= 6f;

        t += ev.tempOffset;

        // underground / indoors the temperature drifts to a stable ~10 degrees
        if (!level.canSeeSky(pos.above())) {
            t = 10f + (t - 10f) * 0.35f;
        }

        if (level.isRainingAt(pos)) t -= 3f;
        if (p.isInWater()) t -= (t > 20f) ? 8f : 3f;

        t += heat(level, pos);

        if (t < 15f) t += 3f * leatherPieces(p);
        return t;
    }

    private static int leatherPieces(ServerPlayer p) {
        int n = 0;
        for (ItemStack a : p.getArmorSlots()) {
            if (a.getItem() instanceof ArmorItem ai && ai.getMaterial() == ArmorMaterials.LEATHER) n++;
        }
        return n;
    }

    private static float heat(ServerLevel level, BlockPos pos) {
        float h = 0f;
        for (BlockPos bp : BlockPos.betweenClosed(pos.offset(-3, -2, -3), pos.offset(3, 2, 3))) {
            BlockState st = level.getBlockState(bp);
            if (st.isAir()) continue;
            if (st.is(BlockTags.FIRE)
                    || st.getFluidState().is(FluidTags.LAVA)
                    || (st.is(BlockTags.CAMPFIRES) && st.getValue(CampfireBlock.LIT))
                    || (st.getBlock() instanceof AbstractFurnaceBlock && st.getValue(AbstractFurnaceBlock.LIT))) {
                h += 8f;
            } else if (st.is(Blocks.TORCH) || st.is(Blocks.WALL_TORCH) || st.is(Blocks.LANTERN)) {
                h += 1f;
            }
        }
        return Math.min(h, 25f);
    }
}
