package com.example.fourseasons;

import java.util.List;
import java.util.Locale;

import javax.annotation.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class ThermometerItem extends Item {
    public ThermometerItem(Properties props) {
        super(props);
    }

    private static String fmt(float v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp && level instanceof ServerLevel sl) {
            if (level.dimension() != Level.OVERWORLD) {
                sp.displayClientMessage(Component.translatable("msg.fourseasons.thermometer.none"), true);
            } else {
                SeasonManager.Info info = SeasonManager.info(sl);
                float amb = TemperatureManager.ambient(sp, info.season(), SeasonManager.event(sl));
                float body = sp.getPersistentData().contains(ServerEvents.TEMP_KEY)
                        ? sp.getPersistentData().getFloat(ServerEvents.TEMP_KEY) : 20f;
                sp.displayClientMessage(Component.translatable("msg.fourseasons.thermometer", fmt(amb), fmt(body)), true);
            }
            player.getCooldowns().addCooldown(this, 10);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.fourseasons.thermometer.desc").withStyle(ChatFormatting.GRAY));
    }
}
