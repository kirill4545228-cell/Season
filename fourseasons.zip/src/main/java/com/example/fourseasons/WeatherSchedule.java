package com.example.fourseasons;

import net.minecraft.util.RandomSource;

/**
 * Decides which days of a season have precipitation. Deterministic per world seed and season,
 * so it needs no storage: e.g. winter ~15 of 20 days with a random +/- margin.
 */
public final class WeatherSchedule {
    private static long cSeed;
    private static long cPeriod = Long.MIN_VALUE;
    private static int cLen = -1;
    private static boolean[] cDays = new boolean[0];

    private WeatherSchedule() {}

    private static int baseDays(Season s) {
        return switch (s) {
            case SPRING -> SeasonConfig.PRECIP_SPRING.get();
            case SUMMER -> SeasonConfig.PRECIP_SUMMER.get();
            case AUTUMN -> SeasonConfig.PRECIP_AUTUMN.get();
            case WINTER -> SeasonConfig.PRECIP_WINTER.get();
        };
    }

    private static synchronized boolean[] days(long worldSeed, long period, Season season, int len) {
        if (cPeriod == period && cLen == len && cSeed == worldSeed) return cDays;

        RandomSource r = RandomSource.create(worldSeed ^ (period * 0x9E3779B97F4A7C15L) ^ 0x5EA50AL);
        float scale = len / 20f;
        int base = Math.round(baseDays(season) * scale);
        int var = Math.round(SeasonConfig.PRECIP_VARIANCE.get() * scale);
        int count = base + (var > 0 ? r.nextInt(var * 2 + 1) - var : 0);
        count = Math.max(0, Math.min(len, count));

        int[] idx = new int[len];
        for (int i = 0; i < len; i++) idx[i] = i;
        for (int i = len - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            int t = idx[i]; idx[i] = idx[j]; idx[j] = t;
        }
        boolean[] res = new boolean[len];
        for (int i = 0; i < count; i++) res[idx[i]] = true;

        cSeed = worldSeed;
        cPeriod = period;
        cLen = len;
        cDays = res;
        return res;
    }

    public static boolean isPrecipDay(long worldSeed, SeasonManager.Info info) {
        boolean[] d = days(worldSeed, info.period(), info.season(), info.daysPerSeason());
        int i = info.dayInSeason() - 1;
        return i >= 0 && i < d.length && d[i];
    }

    public static int precipDaysInSeason(long worldSeed, SeasonManager.Info info) {
        int n = 0;
        for (boolean b : days(worldSeed, info.period(), info.season(), info.daysPerSeason())) if (b) n++;
        return n;
    }
}
