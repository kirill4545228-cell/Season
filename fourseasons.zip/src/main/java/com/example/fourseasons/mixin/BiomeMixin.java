package com.example.fourseasons.mixin;

import com.example.fourseasons.SeasonHooks;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.biome.Biome;

@Mixin(Biome.class)
public abstract class BiomeMixin {

    /** "Warm enough for rain" is false in winter, so rain turns into snow (rendering, accumulation, freezing). */
    @Inject(method = "warmEnoughToRain", at = @At("HEAD"), cancellable = true, require = 0)
    private void fourseasons$winterSnow(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        Biome self = (Biome) (Object) this;
        if (SeasonHooks.forceSnow(self.getBaseTemperature())) {
            cir.setReturnValue(false);
        }
    }
}
